//
//  refreshUrl.swift
//  Kakaotalk_CloneCoding
//
//  Created by DohyunKim on 2019/12/31.
//  Copyright © 2019 DohyunKim. All rights reserved.
//

import Foundation

let refreshUrl = URL(string: "http://chicksoup.s3.ap-northeast-2.amazonaws.com/refresh")
