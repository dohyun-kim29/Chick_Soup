//
//  ChatViewController.swift
//  Kakaotalk_CloneCoding
//
//  Created by DohyunKim on 27/11/2019.
//  Copyright © 2019 DohyunKim. All rights reserved.
//

import UIKit


class ChatViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
